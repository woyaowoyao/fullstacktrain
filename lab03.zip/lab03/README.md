install and run<br>

git clone https://github.com/woyaowoyao/fullstacktrain.git <br>
cd fullstacktasks\lab03
json-server --watch json-server/db.json

cd react-training-player <br>
npm install <br>
npm start <br>
open browser:<br>
http://localhost:3001/<br>