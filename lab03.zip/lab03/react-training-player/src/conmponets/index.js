
import { PlayerItem } from './PlayerItem'

export default [
  PlayerItem
]
