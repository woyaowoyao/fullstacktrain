install and run<br>

cd lab03
json-server --watch json-server/db.json

git clone https://github.com/woyaowoyao/fullstacktrain/tree/master/lab03  <br>
cd fullstacktasks\lab03 <br>
npm install <br>
npm start <br>
open browser:<br>
http://localhost:3001/<br>