package laidongs.lab04.report;

public class Report {
    protected static void section(String title) {
        System.out.println();
        System.out.println("--------------------------------------------------------------");
        System.out.println(title);
        System.out.println();
    }
}
