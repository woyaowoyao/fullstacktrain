1.Run the app in tomcat8.x
2.open browser http://localhost:8080/course-app/login
3.input admin/admin
4.browser homepage